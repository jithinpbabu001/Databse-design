DROP DATABASE IF EXISTS college_dbs;
CREATE DATABASE college_dbs;
USE college_dbs;

CREATE TABLE students (
  student_id        INT            PRIMARY KEY   AUTO_INCREMENT,
  first_name      VARCHAR(255)   NOT NULL,
  last_name      VARCHAR(255)   NOT NULL,
  email        VARCHAR(255)   NOT NULL
);

CREATE TABLE departments (
  department_id           INT            PRIMARY KEY   AUTO_INCREMENT,
  department_name      VARCHAR(255)   NOT NULL
);
CREATE TABLE courses (
  course_id         INT            PRIMARY KEY   AUTO_INCREMENT,
  course_name        VARCHAR(255)   NOT NULL UNIQUE,
  department_id        INT   NOT NULL,
  CONSTRAINT courses_students
    FOREIGN KEY (department_id)
    REFERENCES departments(department_id)
    
);
CREATE TABLE instructor (
  instructor_id        INT            PRIMARY KEY   AUTO_INCREMENT,
  first_name      VARCHAR(255)   NOT NULL,
  last_name      VARCHAR(255)   NOT NULL,
  email        VARCHAR(255)   NOT NULL,
  department_id    INT   NOT NULL,
  course_id      INT   NOT NULL,
  CONSTRAINT instructor_fk_students
    FOREIGN KEY (department_id)
    REFERENCES departments(department_id),
    CONSTRAINT courses_student_instructors
    FOREIGN KEY (course_id)
    REFERENCES courses(course_id)
);


CREATE TABLE department_heads (
  department_id           INT      NOT NULL     UNIQUE,
  department_head      INT    NOT NULL     UNIQUE,
  CONSTRAINT department_student
    FOREIGN KEY (department_id)
    REFERENCES departments(department_id),
    CONSTRAINT department_fk_students
    FOREIGN KEY (department_head)
    REFERENCES instructor(instructor_id)

);



CREATE TABLE enrollment (
  student_id        INT       NOT NULL,
  course_id        INT       NOT NULL,
  CONSTRAINT students_fk_enrollment
    FOREIGN KEY (student_id)
    REFERENCES students(student_id),
    CONSTRAINT courses_fk_enrollment
    FOREIGN KEY (course_id)
    REFERENCES courses(course_id)
);



  